% S12 study (Options 1–3) with solver sweeps, CPU summary, and overlay plots.

clear; clc; close all;

%  base parameters 
J1 = 100;  
b1 = 1;
J2 = 1;    
b2 = 1;
k_list  = [10, 100, 1000];         % shaft stiffness sweep (Option 1)
A_list  = [1, 100];                % step amplitudes
useStep = 1;  
amp = 1;  
freq = 5;  % input selector: 1=step(A), 0=sin(amp*sin(2πf t))
Tf = 25;

% initial conditions
w01 = 0; 
th01 = 0;                 % side 1
w02 = 0; 
th02 = 0;                 % side 2
show_key = 'ode45';

% Simulink model
mdl = 'S12';  

%  push to base
push = @(n,v) assignin('base',n,v);
cellfun(@(p) push(p{1},p{2}), {
  {'J1',J1},{'b1',b1},{'J2',J2},{'b2',b2}, ...
  {'useStep',useStep},{'amp',amp},{'freq',freq}, ...
  {'w01',w01},{'th01',th01},{'w02',w02},{'th02',th02}, ...
  {'Tf',Tf}});

load_system(mdl);
set_param(mdl,'StopTime',num2str(Tf));

%  solver sets to test 
fixed_solvers = {'ode1','ode4'};
fixed_dts     = {'0.1','1'};       % seconds
var_solvers   = {'ode45'};         % variable-step

%  store
rows = strings(0,1);
CPU  = [];                         % seconds
R    = struct;                     % traces to overlay (per A,k)

for Ai = 1:numel(A_list)
  A = A_list(Ai);
  push('A',A);                     % step amplitude for useStep==1

  for kk = 1:numel(k_list)
    k = k_list(kk);
    push('k',k);

    % - variable-step tests -
    for s = 1:numel(var_solvers)
      [tout,out,cpu] = run_once(mdl,var_solvers{s},'');
      rows(end+1) = sprintf('A=%g  k=%g  | %s',A,k,var_solvers{s});  
      CPU(end+1,1) = cpu;

      key = var_solvers{s};     % e.g., 'ode45'
      R.(key).t   = tout;
      R.(key).w1  = out.opt1.w1;   % ω1 flex
      R.(key).w2  = out.opt1.w2;   % ω2 flex
      R.(key).wL  = out.opt2.w;    % lumped ω
      R.(key).wS2 = out.opt3.w;    % S2 integrates ω
    end

    % fixed-step tests 
    for s = 1:numel(fixed_solvers)
      for d = 1:numel(fixed_dts)
        [tout,out,cpu] = run_once(mdl,fixed_solvers{s},fixed_dts{d});
        rows(end+1) = sprintf('A=%g  k=%g  | %s dt=%s',A,k,fixed_solvers{s},fixed_dts{d});
        CPU(end+1,1) = cpu;

        key = sprintf('%s_dt%s',fixed_solvers{s},fixed_dts{d}); % 'ode4_dt0.1', etc.
        R.(key).t   = tout;
        R.(key).w1  = out.opt1.w1;
        R.(key).w2  = out.opt1.w2;
        R.(key).wL  = out.opt2.w;
        R.(key).wS2 = out.opt3.w;
      end
    end

    % - comparison plot: Option 1 vs 2 vs 3 (pick one solver trace via show_key) -
    if isfield(R,show_key)
      T = R.(show_key).t;
      figure('Name',sprintf('A=%g, k=%g',A,k)); hold on; grid on;
      plot(T, R.(show_key).w1, 'r-',  'DisplayName','Opt1 \omega_1');
      plot(T, R.(show_key).w2, 'm--', 'DisplayName','Opt1 \omega_2');
      plot(T, R.(show_key).wL, 'b-.', 'DisplayName','Opt2 (lumped) \omega');
      plot(T, R.(show_key).wS2,'g:',  'DisplayName','Opt3 (S2 integrates) \omega');
      xlabel('t [s]'); ylabel('\omega [rad/s]');
      title(sprintf('Compare Options  (A=%g,  k=%g,  %s)',A,k,show_key));
      legend('Location','best');
    end
  end
end

%  CPU table 
T = table(rows, CPU, 'VariableNames',{'case','cpu_s'});
disp(T);

% helper: one simulation with selected solver
function [t,out,cpu] = run_once(mdl, solver, fixedStep)
  if any(strcmp(solver,{'ode1','ode4'}))
    set_param(mdl,'Solver',solver,'FixedStep',fixedStep);
  else
    set_param(mdl,'Solver',solver);
  end
  tic;
  simOut = sim(mdl,'SrcWorkspace','base');  % model must write arrays to base
  cpu = toc;

  
  t = simOut.tout;
  out.opt1.w1 = simOut.get('out_opt1_w1');  
  out.opt1.w2 = simOut.get('out_opt1_w2');
  out.opt2.w  = simOut.get('out_opt2_w');
  out.opt3.w  = simOut.get('out_opt3_w');

  % Force column vectors
  f = @(x) x(:);
  out.opt1.w1 = f(out.opt1.w1);  out.opt1.w2 = f(out.opt1.w2);
  out.opt2.w  = f(out.opt2.w);   out.opt3.w  = f(out.opt3.w);
end

function taud = fDamper(b, omega)
% Viscous damping torque = b * omega
    taud = b .* omega;
end

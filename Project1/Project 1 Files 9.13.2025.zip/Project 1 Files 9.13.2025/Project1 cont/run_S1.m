% run_S1_sweep_plus_fixed.m
% S1 study across parameter sets with RK4(dt=0.001) reference.
% Fixes struct-append error by using a template struct for all runs.

clear; clc; close all;

% parameter sets (edit/add as needed)
cases = [ ...
    struct('name','CaseA','J',100,'b',10,'w0',10,'theta0',0,'Tf',25, ...
           'useStep',0,'A',100,'amp',1,'freq',0.1), ...
    struct('name','CaseB','J',0.01,'b',0.1,'w0',10,'theta0',0,'Tf',0.5, ...
           'useStep',0,'A',100,'amp',1,'freq',100) ...
];

mdl = 'part1'; % Simulink model (To Workspace: w, theta, optional t_in), save format = Array

% solver selections
fixed_dts      = {'0.001','0.01','0.1','1'}; % for ode1/ode4
fixed_solvers  = {'ode1','ode4'};            % Euler, RK4
var_solvers    = {'ode45','ode23tb'};        % variable-step (dt ignored)

load_system(mdl);

for c = 1:numel(cases)
    % base parameters for this case
    J = cases(c).J; b = cases(c).b; w0 = cases(c).w0; theta0 = cases(c).theta0;
    Tf = cases(c).Tf; useStep = cases(c).useStep; A = cases(c).A;
    amp = cases(c).amp; freq = cases(c).freq;

    % push constants to base workspace
    push=@(n,v) assignin('base',n,v);
    cellfun(@(p) push(p{1},p{2}), {
        {'J',J},{'b',b},{'w0',w0},{'theta0',theta0},...
        {'useStep',useStep},{'A',A},{'amp',amp},{'freq',freq}});

    set_param(mdl,'StopTime',num2str(Tf));

    % reference trace
    % note that for sine: RK4 dt=0.001 is the "analytic" reference
    set_param(mdl,'Solver','ode4','FixedStep','0.001');
    tic; refOut = sim(mdl,'SrcWorkspace','base'); refCPU = toc;
    t_ref = refOut.tout;
    w_ref = refOut.get('w');     w_ref = w_ref(:);
    th_ref= refOut.get('theta'); th_ref= th_ref(:);
    t_in_ref = try_get(refOut,'t_in'); if isempty(t_in_ref), t_in_ref=zeros(size(t_ref)); end
    tau_b_ref = b .* w_ref;

    if useStep==1
        % closed-form for step input: w(t) = A/b + (w0 - A/b)*exp(-(b/J)*t)
        w_true_ref = (A/b) + (w0 - A/b)*exp(-(b/J)*t_ref);
    end

    % template struct and container (prevents "dissimilar structures" error)
    emptyRun = struct('solver','','dt','','t',[],'w',[],'theta',[], ...
                      'tau_in',[],'tau_b',[],'cpu',NaN,'maxErr',NaN);
    runs = repmat(emptyRun,0,1);

    % 1) fixed-step solvers at several dt
    for s = 1:numel(fixed_solvers)
        for d = 1:numel(fixed_dts)
            [t,w,theta,tau_in,tau_b,cpu] = run_model(mdl,fixed_solvers{s},fixed_dts{d},b);
            r = emptyRun;
            r.solver=fixed_solvers{s}; r.dt=fixed_dts{d};
            r.t=t; r.w=w; r.theta=theta; r.tau_in=tau_in; r.tau_b=tau_b; r.cpu=cpu;
            runs(end+1) = r; %#ok<SAGROW>
        end
    end

    % 2) variable-step solvers
    for s = 1:numel(var_solvers)
        [t,w,theta,tau_in,tau_b,cpu] = run_model(mdl,var_solvers{s},'',b); % dt N/A
        r = emptyRun;
        r.solver=var_solvers{s}; r.dt='var';
        r.t=t; r.w=w; r.theta=theta; r.tau_in=tau_in; r.tau_b=tau_b; r.cpu=cpu;
        runs(end+1) = r; %#ok<SAGROW>
    end

    % compute errors vs reference
    for k = 1:numel(runs)
        tk = runs(k).t; wk = runs(k).w;
        if useStep==0
            w_ref_i = interp1(t_ref, w_ref, tk, 'linear','extrap');
            err = abs(wk - w_ref_i);
        else
            w_true_k = (A/b) + (w0 - A/b)*exp(-(b/J)*tk);
            err = abs(wk - w_true_k);
        end
        runs(k).maxErr = max(err);
    end

    % summary table
    solv = string({runs.solver})';
    dtv  = string({runs.dt})';
    cpu  = [runs.cpu]';
    err  = [runs.maxErr]';
    T = table(solv, dtv, cpu, err, 'VariableNames',{'solver','dt','cpu_s','maxErr'});
    fprintf('\n==== %s  (J=%.4g, b=%.4g, freq=%.4g) ====\n', cases(c).name,J,b,freq);
    disp(T);

    % overlay plot (omega vs reference)
    showIdx = find(strcmp({runs.solver},'ode45'),1); % example
    figure;
    plot(runs(showIdx).t, runs(showIdx).w,'DisplayName','test'); hold on;
    if useStep==0
        plot(t_ref, w_ref,'--','DisplayName','RK4 dt=0.001 ref');
    else
        plot(t_ref, w_true_ref,'--','DisplayName','analytic (closed-form)');
    end
    grid on; xlabel('t [s]'); ylabel('\omega [rad/s]');
    title(sprintf('%s: S1 \\omega  test=%s  dt=%s', cases(c).name, runs(showIdx).solver, runs(showIdx).dt)); legend;

    % torques (reference)
    figure;
    plot(t_ref, t_in_ref,'DisplayName','\tau_{in}'); hold on;
    plot(t_ref, tau_b_ref,'--','DisplayName','\tau_b=b\omega'); grid on;
    xlabel('t [s]'); ylabel('\tau [N·m]');
    title(sprintf('%s: Torques (reference)', cases(c).name)); legend;

    % error vs dt for fixed-step solvers
    figure; hold on; grid on;
    for s = 1:numel(fixed_solvers)
        mask = strcmp({runs.solver}, fixed_solvers{s});
        dts  = string({runs(mask).dt});
        x = str2double(strrep(dts,'var','NaN'));
        [xsorted, idx] = sort(x);
        plot(xsorted, [runs(mask).maxErr], 'o-','DisplayName',fixed_solvers{s});
    end
    set(gca,'XScale','log','YScale','log');
    xlabel('fixed step \Delta t [s]'); ylabel('max |error| [rad/s]');
    title(sprintf('%s: Max error vs step size', cases(c).name)); legend;

    % CPU vs dt (fixed-step only)
    figure; hold on; grid on;
    for s = 1:numel(fixed_solvers)
        mask = strcmp({runs.solver}, fixed_solvers{s});
        x = str2double(strrep(string({runs(mask).dt}),'var','NaN'));
        [xsorted, idx] = sort(x);
        plot(xsorted, [runs(mask).cpu], 'o-','DisplayName',fixed_solvers{s});
    end
    set(gca,'XScale','log');
    xlabel('fixed step \Delta t [s]'); ylabel('CPU time [s]');
    title(sprintf('%s: CPU time vs step size', cases(c).name)); legend;

    % Error vs CPU (all solvers)
    figure; grid on; hold on;
    for k=1:numel(runs)
        plot(runs(k).cpu, runs(k).maxErr,'o','DisplayName',sprintf('%s dt=%s',runs(k).solver,runs(k).dt));
    end
    set(gca,'YScale','log');
    xlabel('CPU time [s]'); ylabel('max |error| [rad/s]');
    title(sprintf('%s: Max error vs CPU time', cases(c).name)); legend('Location','eastoutside');

    % optional: contour sweep over frequency for sine case (RK4 only)
    if useStep==0
        freq_list = logspace(log10(0.1), log10(100), 12);
        dt_list   = [0.001 0.01 0.1];
        ERR = zeros(numel(dt_list), numel(freq_list));
        CPU = zeros(numel(dt_list), numel(freq_list));
        for ii = 1:numel(dt_list)
            set_param(mdl,'Solver','ode4','FixedStep',num2str(dt_list(ii)));
            for jj = 1:numel(freq_list)
                push('freq', freq_list(jj));
                tic; out = sim(mdl,'SrcWorkspace','base'); CPU(ii,jj)=toc;
                t  = out.tout;  w = out.get('w'); w = w(:);
                w_ref_i = interp1(t_ref, w_ref, t, 'linear','extrap');
                ERR(ii,jj) = max(abs(w - w_ref_i));
            end
        end
        figure; contourf(freq_list, dt_list, log10(ERR), 20); colorbar;
        set(gca,'XScale','log','YScale','log');
        xlabel('\omega_{in} [rad/s]'); ylabel('\Delta t [s]');
        title(sprintf('%s: log_{10}(max|error|) (RK4)',cases(c).name));
        figure; contourf(freq_list, dt_list, CPU, 20); colorbar;
        set(gca,'XScale','log','YScale','log');
        xlabel('\omega_{in} [rad/s]'); ylabel('\Delta t [s]');
        title(sprintf('%s: CPU time [s] (RK4)',cases(c).name));
        push('freq', freq); % restore
    end
end

% helper: safe get from SimulationOutput (returns [] if var missing)
function v = try_get(simOut, name)
    try, v = simOut.get(name); v = v(:);
    catch, v = [];
    end
end

% helper: one simulation
function [t,w,theta,tau_in,tau_b,cpu] = run_model(mdl, solver, fixedStep, b)
    if any(strcmp(solver,{'ode1','ode4'}))
        set_param(mdl,'Solver',solver,'FixedStep',fixedStep);
    else
        set_param(mdl,'Solver',solver);
    end
    tic; out = sim(mdl,'SrcWorkspace','base'); cpu = toc;
    t = out.tout;
    w = out.get('w');       w = w(:);
    theta = out.get('theta'); theta = theta(:);
    tau_in = try_get(out,'t_in'); if isempty(tau_in), tau_in = zeros(size(w)); end
    tau_b  = b .* w;
end

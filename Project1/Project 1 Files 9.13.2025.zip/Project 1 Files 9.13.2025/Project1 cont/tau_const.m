function tau = tau_const(t, A)
% Constant torque input
tau = A;   % always returns same torque
end